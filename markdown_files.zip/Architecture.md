**Architecture & Coding Standards**

This document defines the structural backbone of our Java Chat Application. All code merged into this repository must adhere strictly to the design patterns, networking standards, and coding conventions outlined below.

Our architecture is designed to be **modular and scalable**. The decisions made here ensure that when we transition from a terminal interface to a graphical interface, we do not have to rewrite our underlying network logic.

**1\. Project Directory & Package Hierarchy**

All Java source code must reside within the src/ directory under a standardized package structure. We strictly separate Client logic, Server logic, and Shared data.

/src

/com/chatapp/server # SERVER-SIDE ARCHITECTURE

/core # Server setup (Server.java)

/handlers # (V2+) ClientHandler threads

/services # (V3+) Broadcast logic, Room management

/database # (V5) JDBC connections and DAOs

/com/chatapp/client # CLIENT-SIDE ARCHITECTURE

/core # Network setup (Client.java)

/controllers # Logic bridging Network and UI

/ui # Presentation layer (Console scanners -> JavaFX)

/com/chatapp/shared # SHARED DEPENDENCIES

/models # (V4+) Custom Message objects, User objects

/utils # Global constants (e.g., Config.PORT)

_Rule: A class in the client package must NEVER import a class from the server package, and vice versa. They only interact over the network._

**2\. Core Design Patterns**

**The Model-View-Controller (MVC) Pattern**

To ensure a smooth transition to Version 3 (GUI), the Client application must decouple its network logic from its presentation logic immediately.

- **View (/ui):** Responsible _only_ for capturing input and displaying output.
    - In V1, this is a Scanner(System.in) and System.out.println().
    - It must NOT contain socket logic. It simply passes captured strings to the Controller.
- **Controller (/controllers):** The brain. It receives strings from the View, formats them, and pushes them through the Socket. It also listens to the Socket and tells the View to display incoming messages.
- **Model (/models):** The data structure. (e.g., maintaining the list of active users or the chat history).

**The Threading Model (Version 2+)**

Network I/O in Java relies on **blocking methods** (like .accept() and .readLine()). To prevent the application from freezing, we mandate the following threading architecture:

1.  **Server Acceptor Thread:** The main server thread runs a continuous while(true) loop calling serverSocket.accept(). It does _nothing else_.
2.  **Client Handlers:** Upon a successful connection, the server immediately spawns a new Thread (or implements Runnable) dedicated entirely to that specific client.
3.  **Client Background Listener:** The client must have a dedicated background thread running in.readLine() continuously, freeing up the main thread to capture user keyboard input without waiting.

**3\. Networking & I/O Standards**

**Wrapping Streams Safely**

Do not pass raw bytes. We are building a text-based chat, so we use character streams. You must wrap your sockets exactly like this:

**For Receiving (BufferedReader):**

// Efficiently reads lines of text

BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

String incomingMessage = in.readLine();

**For Sending (PrintWriter):**

// The 'true' argument enables auto-flush. THIS IS MANDATORY.

// Without auto-flush, your messages will get trapped in the buffer and never send.

PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

out.println("Your message here"); // Always use println, not print

**Resource Management**

Sockets are limited OS resources. If a user disconnects, you must release the port. Always close your sockets in a finally block or use Java's try-with-resources.

try {

// Network logic

} catch (IOException e) {

System.err.println("Network error: " + e.getMessage());

} finally {

if (socket != null && !socket.isClosed()) {

socket.close(); // Mandatory cleanup

}

}

**4\. Data Transfer Protocol (The Roadmap)**

- **Versions 1, 2 & 3:** We will send raw String objects back and forth.
- **Version 4 (The Network Update):** We will transition to JSON. We will stop using out.println("Hello") and start using structured payloads to differentiate between commands and chat.
    - _Example Future Payload:_ {"type": "CHAT", "sender": "Alice", "body": "Hello!"}
    - _Example Future Command:_ {"type": "COMMAND", "action": "DISCONNECT"}

**5\. Strict Java Coding Standards**

Code that does not meet these standards will be rejected during Pull Request reviews.

1.  **Strict Encapsulation:** All class variables MUST be private or protected. If another class needs access, write a public getVariable() method. Never mutate variables directly.
2.  **Meaningful Naming:**
    - Classes are PascalCase (e.g., ClientHandler).
    - Methods and variables are camelCase (e.g., sendMessage, socket).
    - No single-letter variables except for standard loops (for int i = 0;). BufferedReader b is rejected; use BufferedReader reader or in.
3.  **Exception Handling:** **Never swallow exceptions.**
    - _Rejected:_ catch (Exception e) {}
    - _Accepted:_ catch (IOException e) { System.err.println("Failed to connect: " + e.getMessage()); }
4.  **Javadoc Documentation:** Every class and every public method must have a Javadoc block explaining what it does, what its parameters are, and what it returns.

/\*\*

\* Broadcasts a message to all connected clients in the server's tracking list.

\* \* @param message The text message to send.

\* @param sender The username of the person who sent the message.

\*/

public void broadcastMessage(String message, String sender) {

// Implementation

}