**Collaboration and Git Workflow Guide**

Welcome to the team! This document is the absolute centerpiece of our project's infrastructure. Because multiple developers will be touching the same Java files simultaneously, we need a strict, predictable system to ensure we don't overwrite each other's work or break the application.

We are utilizing a Shared Repository Feature Branch Workflow. This means we all share write access to this single repository, but we never write directly to the primary codebase.

Never, under any circumstances, commit or push directly to the main branch. The main branch is sacred. It must only contain reviewed, tested, and 100% functional code. If someone clones the main branch, it should compile and run flawlessly. All development work happens on isolated Feature Branches.

**1\. Prerequisites & Setup**

Before you write your first line of code, ensure your local environment is configured correctly.

Clone the Repository: \`\`\`bash git clone https://github.com/YOUR-ORG/Java-Chat-App.git cd Java-Chat-App

Configure Git Identity: Ensure your commits are tied to your name.

_git config user.name "Your Name"_

_git config user.email "your.email@example.com"_

IDE Setup: Ensure your IDE (IntelliJ/Eclipse) is set to automatically format code using standard Java conventions. This prevents "formatting-only" commits that clog up code reviews.

**2\. The Daily Development Loop**

Every single time you pick up a task from the Kanban board, you must follow this exact step-by-step lifecycle.

**Step 1: Sync with the Team**

Always start by ensuring your local machine has the latest approved code.

_git checkout main_

_git pull origin main_

**Step 2: Create your Feature Branch**

Create an isolated "sandbox" branch for your specific task.

_git checkout -b &lt;branch-category&gt;/&lt;branch-name&gt;_

**Strict Branch Naming Conventions:**

_feat/... for new features (e.g., feat/server-socket-init)_

_fix/... for bug fixes (e.g., fix/client-null-pointer)_

_refactor/... for restructuring code without changing behavior (e.g., refactor/extract-io-methods)_

_docs/... for updating documentation (e.g., docs/update-readme)_

**Step 3: Write Code & Commit Frequently**

Write your Java code and test it locally. Save your progress often using Git commits.

Commit Message Guidelines (Conventional Commits): Commit messages must be descriptive. A teammate should know exactly what changed without looking at the code.

_Bad: git commit -m "fixed stuff"_

_Bad: git commit -m "WIP"_

_Good: git commit -m "feat: implement BufferedReader for incoming server messages"_

_Good: git commit -m "fix: resolve ConnectException when server is offline"_

_git add ._

_git commit -m "type: brief description of changes"_

**Step 4: Push to the Remote Repository**

Once your feature is complete and tested on your machine, push your isolated branch up to GitHub.

_git push origin &lt;your-branch-name&gt;_

**3\. The Pull Request (PR) Lifecycle**

Pushing your code does not merge it into main. You must request permission to merge via a Pull Request.

**Opening a PR**

1.  Go to the repository on GitHub. You will see a green button: "Compare & pull request". Click it.
2.  Title: Make it clear (e.g., "Feature: Initialize Client Socket Connection").
3.  Description: You must include:

- What this PR does.
- Which Kanban ticket it resolves (e.g., "Closes Task #4").
- How to test it locally (e.g., "Run Server.java, then run Client.java, and verify connection print statement").

**The Peer Review Process**

Code review is how we catch bugs and learn from each other.

1.  Assign a Reviewer: Tag at least one other team member to review your PR.
2.  Reviewer Duties: The reviewer must read the code, look for edge cases (e.g., "What happens if this socket throws an IOException here?"), and optionally pull the branch to test it locally.
3.  Requesting Changes: If the reviewer finds an issue, they will request changes. You do not need to open a new PR. Simply make the fixes on your local branch, git add, git commit, and git push again. The PR will update automatically.
4.  Approval & Merge: Once the reviewer clicks "Approve", the PR author (or the reviewer) can click the green "Merge" button to integrate the code into main.

**Cleanup**

After your PR is merged, clean up your local machine:

_git checkout main_

_git pull origin main_

_git branch -d &lt;your-merged-branch-name&gt; # Deletes the local feature branch_

**4\. Handling Merge Conflicts**

Eventually, Git will yell at you: Merge conflict in src/.../Server.java. Do not panic. A conflict simply means you and a teammate edited the exact same line of code, and Git needs a human to decide which version to keep.

How to resolve it:

1.  Make sure your local main is updated: git checkout main -> git pull origin main.
2.  Go back to your feature branch: git checkout feat/your-branch.
3.  Attempt to merge main into your branch: git merge main.
4.  Git will tell you which files have conflicts. Open those files in your IDE.
5.  Your IDE will highlight the conflicts with &lt;<<<<<< HEAD and &gt;>>>>>> main.
6.  Edit the code to combine both features correctly. Delete the <<<<<<< and ====== markers.
7.  Save the file, then run:

_git add ._

_git commit -m "fix: resolve merge conflict with main”_

_git push origin feat/your-branch_

Your PR will now be free of conflicts and ready to merge!

**5\. Communication Etiquette**

- Don't code in the dark: If you are stuck on a Java bug for more than 45 minutes, push your branch, open a "Draft PR", and ask for help in the Discord #dev-talk channel.
- Respect the board: Never start working on a feature without moving the ticket to "In Progress" on the Kanban board. Two people building the same feature is a waste of time.
- Fast Reviews: Aim to review your teammates' PRs within 24 hours so nobody is blocked from moving forward.