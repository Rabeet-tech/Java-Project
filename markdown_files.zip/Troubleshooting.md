**Troubleshooting & Network Bug Knowledge Base**

Writing networked Java applications introduces bugs that do not exist in standalone programs. Before asking for help or spending hours on StackOverflow, check this guide for the most common socket errors.

**1\. java.net.BindException: Address already in use**

- **The Symptom:** You run Server.java, and it crashes immediately with this red error.
- **The Cause:** You cannot have two applications listening on the same port at the same time. You likely ran the server, didn't shut it down properly, and clicked "Run" again. The original server is still running in the background holding Port 6666 hostage.
- **The Fix:**

\* In IntelliJ/Eclipse, find the "Stop" button (usually a red square) and click it to kill background processes.

_Advanced:_ Open your OS Task Manager / Activity Monitor and kill lingering java.exe processes.

**2\. java.net.ConnectException: Connection refused**

- **The Symptom:** You run Client.java, and it crashes immediately with this error.
- **The Cause:** The client knocked on localhost:6666, but nothing was there to answer.
- **The Fix:** Order of operations matters! You **must** run Server.java first. Wait until the console prints "Waiting for client...", and _only then_ run Client.java.

**3\. The Program Hangs / Messages Never Arrive**

- **The Symptom:** Both the Client and Server connect successfully. You type a message on the Client, hit Enter, but the Server console remains completely blank. Both programs are frozen.
- **The Cause:** The "Buffer Trap". Network streams don't send data letter-by-letter; they hold onto data in a buffer until it's full, then send it in a chunk to save bandwidth. You forgot to tell Java to push the chunk.
- **The Fix:**

**Option A (Best):** When initializing your PrintWriter, add true as the second argument to enable auto-flushing. new PrintWriter(socket.getOutputStream(), true);

**Option B:** Always call out.flush(); immediately after calling out.print().

**Crucial Note:** Always use println() instead of print(). BufferedReader.readLine() waits indefinitely for a line break (\\n). If you don't send one, it waits forever.

**4\. NullPointerException when chatting**

- **The Symptom:** You are chatting back and forth. You close the Client terminal. Suddenly, the Server throws a massive error and crashes.
- **The Cause:** in.readLine() does not throw an error when a socket disconnects gracefully. Instead, it returns null. If your code tries to print or manipulate that null value, the app crashes.
- **The Fix:** Always implement a null-check in your while(true) reading loop.

String incoming = in.readLine();

if (incoming == null) {

System.out.println("The other user disconnected.");

break; // Break out of the while loop safely

}

**5\. Why do we have to take turns? (The Blocking Trap)**

- **The Symptom:** In Version 1, if the Client tries to send two messages in a row, the app breaks.
- **The Cause:** Standard Java I/O methods like Scanner.nextLine() and BufferedReader.readLine() are **Blocking Methods**. They completely freeze the thread they are running on until they receive input.
- **The Fix (Looking Ahead):** This is intended behavior for Version 1. To fix this, we need to upgrade to **Version 2**. We will introduce Java Multithreading (Thread objects) so that reading the network and typing on the keyboard happen on two parallel, independent tracks.