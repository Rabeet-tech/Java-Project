# Sprint 1 Execution: Version 1 (The Foundation)

**Sprint Goal:** Establish a 1-on-1 socket connection. The Client types a message, the Server receives and prints it, and then the Server replies.

Note: Because we are not using multithreading yet, this version will act strictly like a walkie-talkie. You must take turns sending messages.

## Phase 1: Prerequisite Knowledge

Before claiming a task on the Kanban board, ensure you understand the following Java classes.

- **java.net.ServerSocket**: Used only by the server to listen for incoming knocks on a port.
- **java.net.Socket**: Used by the client to knock on the server's door, AND returned by the server to represent the actual connection.
- **java.io.BufferedReader & java.io.PrintWriter**: The text-stream wrappers we use to read and write over the network.
- **Runtime.getRuntime().addShutdownHook()**: Used to execute cleanup code when the terminal is closed.

## Phase 2: Active Kanban Tasks (6 Developers)

To ensure all 6 team members can code in parallel without massive merge conflicts, we have divided the MVP into 6 distinct tickets. Claim one, create your feature branch, and build it out.

### Task 1: Shared Configuration & Constants (Assign to Dev 1)

**Objective:** Prevent hardcoding IPs and Ports across different files by creating a central configuration file. **File to Create:** src/com/chatapp/shared/utils/Config.java **Execution Steps:**

1.  Create a public class Config.
2.  Define public static final int PORT = 6666;
3.  Define public static final String HOST = "127.0.0.1";
4.  Add a standard system prefix: public static final String SERVER_PREFIX = "\[SERVER\]: ";
5.  Note: Let Devs 2 & 3 know when this is merged so they can use Config.PORT instead of hardcoding 6666.

### Task 2: The Server Skeleton (Assign to Dev 2)

**Objective:** Set up the host process that waits for a connection. **File to Create:** src/com/chatapp/server/core/Server.java **Execution Steps:**

1.  Create a main method.
2.  Wrap your logic in a try-catch(IOException e) block.
3.  Instantiate ServerSocket serverSocket = new ServerSocket(Config.PORT);
4.  Print to the console: "Server started on port " + Config.PORT + ". Waiting for a client..."
5.  Pause the application to wait for a connection using: Socket clientSocket = serverSocket.accept();
6.  Once the line above unblocks, print: "Client Connected from " + clientSocket.getInetAddress()

### Task 3: The Client Skeleton (Assign to Dev 3)

**Objective:** Set up the client process that knocks on the server's door. **File to Create:** src/com/chatapp/client/core/Client.java **Execution Steps:**

1.  Create a main method.
2.  Wrap your logic in a try-catch(IOException e) block.
3.  Instantiate the connection: Socket socket = new Socket(Config.HOST, Config.PORT);
4.  Print to the console: "Successfully connected to the server at " + Config.HOST

### Task 4: Server Communication Loop (Assign to Dev 4)

**Objective:** Add the ability for the Server to receive and send text. **Dependency:** Wait for Dev 2 to merge the Server Skeleton, then branch off of the updated main. **Execution Steps:**

1.  After clientSocket is created, initialize the streams:
    - BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
    - PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true); // true = autoFlush
    - Scanner consoleInput = new Scanner(System.in);
2.  Create a while(true) loop.
3.  Inside the loop:
    - Read incoming: String message = in.readLine();
    - Null check: If message is null, break the loop (client disconnected).
    - Print it: System.out.println("Client says: " + message);
    - Type reply: System.out.print("Enter reply: "); String reply = consoleInput.nextLine();
    - Send reply: out.println(reply);

### Task 5: Client Communication Loop (Assign to Dev 5)

**Objective:** Add the ability for the Client to capture keyboard input, send it, and wait for a reply. **Dependency:** Wait for Dev 3 to merge the Client Skeleton, then branch off of the updated main. **Execution Steps:**

1.  After socket is created, initialize the exact same streams (BufferedReader, PrintWriter, Scanner(System.in)).
2.  Create a while(true) loop.
3.  Inside the loop (Notice the flipped order compared to the server!):
    - Type message: System.out.print("Enter message: "); String msg = consoleInput.nextLine();
    - Send message: out.println(msg);
    - Read incoming: String response = in.readLine();
    - Null check: If response is null, break the loop (server disconnected).
    - Print it: System.out.println(Config.SERVER_PREFIX + response);

### Task 6: Graceful Teardown & Resource Management (Assign to Dev 6)

**Objective:** Prevent BindException (Address already in use) memory leaks by ensuring sockets close properly when a user forces the terminal to close (Ctrl+C). **Dependency:** Can be started as soon as Devs 2 & 3 merge their skeletons. **Execution Steps:**

1.  Update Server.java. Below the socket initialization, add a Shutdown Hook:
2.  Runtime.getRuntime().addShutdownHook(new Thread(() -> {
3.  System.out.println("Shutting down server gracefully...");
4.  // Write try-catch block here to call serverSocket.close()
5.  }));
6.  Update Client.java. Add a similar Shutdown Hook to close the Socket and Scanner safely if the user exits the app mid-chat.
7.  Refactor any existing try-catch blocks in both files to use finally blocks to explicitly call .close() on all I/O streams.

## Phase 3: Integration & Testing Protocol

Once all six tasks are complete and merged into the main branch, the team must verify the MVP works.

1.  Pull the latest main branch to your local machine.
2.  Open your terminal and run Server.java. Verify it hangs and says "Waiting...".
3.  Open a **second, separate terminal window** and run Client.java.
4.  Verify the Server terminal registers the connection.
5.  Type a message in the Client terminal. Hit enter.
6.  Verify the message appears in the Server terminal, type a reply, hit enter, and verify it appears in the Client terminal.
7.  Hit Ctrl+C in the Client terminal. Verify the Server detects the disconnect and safely tears down resources (Thanks to Dev 6's code).